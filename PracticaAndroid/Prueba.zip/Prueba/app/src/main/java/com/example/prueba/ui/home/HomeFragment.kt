package com.example.prueba.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.example.prueba.R
import com.example.prueba.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View {
        val homeViewModel =
                ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textHome
        homeViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val viewPager = findViewPager()
        viewPager?.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateIndicators(position)
            }
        })

        binding.buttonEducation.setOnClickListener {
            // Cambia a la página de Education
            findViewPager()?.currentItem = 0
        }

        binding.buttonLocations.setOnClickListener {
            // Cambia a la página de Locations
            findViewPager()?.currentItem = 1
        }
    }

    private fun updateIndicators(position: Int) {
        val indicatorEducation = view?.findViewById<View>(R.id.indicatorEducation)
        val indicatorLocations = view?.findViewById<View>(R.id.indicatorLocations)

        if (position == 0) {
            // Estamos en la página de Education
            indicatorEducation?.visibility = View.VISIBLE
            indicatorLocations?.visibility = View.GONE
        } else {
            // Estamos en la página de Locations
            indicatorEducation?.visibility = View.GONE
            indicatorLocations?.visibility = View.VISIBLE
        }
    }
    private fun findViewPager(): ViewPager2? {
        // Asegúrate de que este método encuentre correctamente el ViewPager2 en tu layout
        return activity?.findViewById(R.id.view_pager)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}